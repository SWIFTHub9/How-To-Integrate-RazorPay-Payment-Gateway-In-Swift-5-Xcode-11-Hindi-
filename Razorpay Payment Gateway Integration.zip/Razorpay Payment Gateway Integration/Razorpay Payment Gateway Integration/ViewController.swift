//
//  ViewController.swift
//  Razorpay Payment Gateway Integration
//
//  Created by Abhishek Verma on 15/02/20.
//  Copyright © 2020 Abhishek Verma. All rights reserved.
//

import UIKit
import Razorpay

class ViewController: UIViewController, RazorpayPaymentCompletionProtocol {

    var razorpay: Razorpay!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        razorpay = Razorpay.initWithKey("", andDelegate: self)
    }
    
    @IBAction func proceedcheckout(_ sender: Any) {
        self.showpaymentform()
    }
    
    internal func showpaymentform()
    {
        let options: [String:Any] = [
            "amount": "100", // 100 rupee = 1 rupee
            "description": "How to use Razorpay Payment Gatway",
            "image": "https://www.supinehub.com/img/SupineHubLogo.gif",
            "name" : "Swift Hub Learning",
            "prefill": [
                "contact" : "0000000000",
                "email" : "demo@gmail.com"
            ],
            "theme": [
                "color" : "#fdc5e7"
            ]
        ]
        razorpay.open(options)
    }

    func onPaymentError(_ code: Int32, description str: String) {
        let alert = UIAlertController(title: "Failure", message: str, preferredStyle: .alert)
        let cancel = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
        alert.addAction(cancel)
        self.view.window?.rootViewController?.present(alert, animated: true, completion: nil)
    }
    
    func onPaymentSuccess(_ payment_id: String) {
         let alert = UIAlertController(title: "Success", message: payment_id, preferredStyle: .alert)
         let cancel = UIAlertAction(title: "OK", style: .cancel, handler: nil)
         alert.addAction(cancel)
         self.view.window?.rootViewController?.present(alert, animated: true, completion: nil)
    }

}

